DROP DATABASE Ware_U_Go

CREATE DATABASE Ware_U_Go

USE Ware_U_Go




CREATE TABLE UserTable
(
Username VARCHAR(20) PRIMARY KEY,
Name VARCHAR(50),
Password VARCHAR(20),
Email VARCHAR(50),
UserType INT
);


CREATE TABLE Product
(
ProductCode INT PRIMARY KEY,
Name VARCHAR(50),
CurrentStock DOUBLE PRECISION,
ThresholdStock DOUBLE PRECISION,
Length INT,
Width INT,
Height INT,
Weight INT,

);



CREATE TABLE Location
(
LocationId INT PRIMARY KEY,
Description VARCHAR(30),
StatusCode INT NOT NULL DEFAULT 0,
Length INT DEFAULT 100,
Width INT DEFAULT 100,
Height INT DEFAULT 100
);



CREATE TABLE InLedger
(
LedgerId INT PRIMARY KEY IDENTITY(1,1),
InDate DATETIME,
Username VARCHAR(20) FOREIGN KEY REFERENCES UserTable(Username),
ProductCode INT FOREIGN KEY REFERENCES Product(ProductCode) NOT NULL,
BatchNumber VARCHAR(100),
Quantity INT,
SupplierName VARCHAR(100),
SupplierLocation VARCHAR(100),
PONumber VARCHAR(30),
PODate DATETIME
);


DROP TABLE InLedgerLocation
CREATE TABLE InLedgerLocation
(
InLedgerLocationID INT PRIMARY KEY IDENTITY(1,1),
LedgerId INT FOREIGN KEY REFERENCES InLedger(LedgerId),
LocationId INT FOREIGN KEY REFERENCES Location(LocationId)
);



CREATE TABLE OutLedger
(
LedgerId INT PRIMARY KEY,
OutDate DATETIME,
ProductCode INT FOREIGN KEY REFERENCES Product(ProductCode) NOT NULL,
Quantity INT,
Validationvar varchar(7)
);


DROP TABLE OutLedgerLocation
CREATE TABLE OutLedgerLocation
(
OutLedgerLocationID INT PRIMARY KEY IDENTITY(1,1),
ledgerId INT FOREIGN KEY REFERENCES OutLedger(LedgerId),
locationId INT FOREIGN KEY REFERENCES Location(LocationId)
);

CREATE TABLE Relocation
(
relocationID INT PRIMARY KEY IDENTITY(1,1),
productcode INT FOREIGN KEY REFERENCES Product(ProductCode) NOT NULL,
OldLocation INT,
NewLocation INT,
Validationvar VARCHAR(40) DEFAULT 'Invalid'
);



-- Inserting dummy data into UserTable
INSERT INTO UserTable (Username, Name, Password, Email, UserType)
VALUES
('ILG2KOR','Aashutosh','Pass@2024','ashu@gmail.com',1),
('BLR2KOR', 'Inayah', 'password3', 'inayah@gmail.com', 1);

-- Inserting dummy data into Product
INSERT INTO Product (ProductCode, Name, CurrentStock, ThresholdStock, Length, Width, Height, Weight)
VALUES
(1, 'Product A', 100, 20, 10, 5, 8, 2),
(2, 'Product B', 50, 10, 15, 6, 9, 3),
(3, 'Product C', 80, 30, 12, 7, 10, 4);

-- Inserting dummy data into Location
INSERT INTO Location (LocationId, Description)
VALUES
(1,'Rack1 Shelf1'),
(2,'Rack1 Shelf2'),
(3,'Rack1 Shelf3'),
																(4,'Rack2 Shelf1'),
																(5,'Rack2 Shelf2'),
																(6,'Rack2 Shelf3'),
																(7,'Rack3 Shelf1'),
																(8,'Rack3 Shelf2'),
																(9,'Rack3 Shelf3')


INSERT INTO Location (LocationId, Description, StatusCode)
VALUES
(10, 'Rack4,Shelf1', 1),
(11, 'Rack4,Shelf2', 1),
(12, 'Rack4,Shelf3', 1);

-- Inserting dummy data into InLedger
INSERT INTO InLedger (InDate, Username, ProductCode, BatchNumber, Quantity, SupplierName, SupplierLocation, PONumber, PODate)
VALUES
('2024-03-18', 'user1', 1, 'Batch001', 50, 'Supplier X', 'Location X', 'PO001', '2024-03-15'),
('2024-03-19', 'user2', 2, 'Batch002', 30, 'Supplier Y', 'Location Y', 'PO002', '2024-03-16'),
('2024-03-20', 'user3', 3, 'Batch003', 40, 'Supplier Z', 'Location Z', 'PO003', '2024-03-17');

-- Inserting dummy data into InLedgerLocation
INSERT INTO InLedgerLocation (LedgerId, LocationId)
VALUES
(1, 10),
(2, 11),
(3, 12);

-- Inserting dummy data into OutLedger
INSERT INTO OutLedger (LedgerId, OutDate, ProductCode, Quantity,Validationvar)
VALUES
(1, '2024-03-21', 1, 20,'Valid');

INSERT INTO OutLedger (LedgerId, OutDate, ProductCode, Quantity)
VALUES
(2, '2024-03-22', 2, 15),
(3, '2024-03-23', 3, 25);

-- Inserting dummy data into OutLedgerLocation
INSERT INTO OutLedgerLocation (LedgerId, LocationId)
VALUES
(1, 10),
(2, 11),
(3, 12);
SELECT * FROM UserTable;

SELECT * FROM Product;
SELECT * FROM InLedger;
SELECT * FROM Location;

SELECT * FROM InLedgerLocation;
SELECT * FROM OutLedger;
SELECT * FROM OutLedgerLocation;
SELECT * FROM Relocation;



----------- Stored Procedures ----------
CREATE PROCEDURE GetProductCart
	AS
	BEGIN
    SELECT 
			P.Name ,
			IL.ProductCode AS ProductCode,
			CASE 
            WHEN IL.ProductCode IS NOT NULL THEN 'inbound'
            ELSE 'unknown'
			END AS TransactionType,
			L.Description AS Description,
			'NULL' AS Validation
 
    FROM 
			InLedger IL
		JOIN 
			InLedgerLocation ILL ON IL.LedgerId = ILL.LedgerId
		JOIN 
			Location L ON ILL.LocationId = L.LocationId
		JOIN
			Product P ON IL.ProductCode = P.ProductCode
 
    UNION ALL
 
    
    SELECT 
			PO.Name ,
			OL.ProductCode AS ProductCode,
			CASE 
            WHEN OL.ProductCode IS NOT NULL THEN 'outbound'
            ELSE 'unknown'
			END AS TransactionType,
			L.Description AS Description,
			OL.Validationvar AS Validation
    FROM 
			OutLedger OL
		JOIN 
			OutLedgerLocation OLL ON OL.LedgerId = OLL.LedgerId
		JOIN 
			Location L ON OLL.LocationId = L.LocationId
		JOIN
			Product PO ON OL.ProductCode = PO.ProductCode;
	END;


	exec GetProductCart


Create Procedure GetSafetyStockIndication
AS
BEGIN
    SELECT Name, ProductCode, 
				  ThresholdStock * 0.95 AS MinimumStock ,
				  ThresholdStock, CurrentStock
    FROM Product
	WHERE CurrentStock < ThresholdStock
END;

exec GetSafetyStockIndication

