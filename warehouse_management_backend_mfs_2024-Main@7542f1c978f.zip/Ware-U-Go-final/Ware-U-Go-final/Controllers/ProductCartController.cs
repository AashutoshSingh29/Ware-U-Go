﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;
namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class ProductCartController : Controller
    {
        Ware_U_GoEntities obj = new Ware_U_GoEntities();
        // GET: ProductCart
        //public ActionResult Index()
        //{
        //    return View();
        //}


        public ActionResult ProductCart()
        {
            ViewBag.Title = "Poduct Cart";
            var lists = obj.GetProductCart().ToList();

            return View(lists);
        }
    }
}