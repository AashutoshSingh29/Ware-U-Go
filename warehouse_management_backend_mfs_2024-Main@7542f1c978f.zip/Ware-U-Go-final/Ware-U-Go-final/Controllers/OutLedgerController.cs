﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;

namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class OutLedgerController : Controller
    {
        // GET: OutLedger
        //public ActionResult Index()
        //{
        //    return View();
        //}

        Ware_U_GoEntities conn = new Ware_U_GoEntities();
        // GET: OutLedger
        public ActionResult Index()
        {
            ViewBag.Title = "Product Outledger";
            return View();
        }





        public ActionResult RequisitionForm()
        {
            ViewBag.Title = "Outledger Requisition Form";
            return View();
        }




        //[HttpPost]
        //public ActionResult RequisitionForm(Product productObj, string DeliveryLocation)
        //{
        //    if (string.IsNullOrEmpty(DeliveryLocation))
        //    {
        //        ModelState.AddModelError("DeliveryLocation", "Delivery location is required.");
        //    }
        //    //if (!ModelState.IsValid)
        //    //{
        //    //    // If ModelState is not valid, return the same view with validation errors
        //    //    return View(productObj);
        //    //}
        //    return RedirectToAction("SearchProduct", productObj);
        //}


        [HttpPost]
        public ActionResult RequisitionForm(Product productObj, string DeliveryLocation)
        {
            ViewBag.Title = "Outledger Requisition Form";
            if (string.IsNullOrEmpty(DeliveryLocation))
            {
                ModelState.AddModelError("DeliveryLocation", "Delivery location is required.");
            }
            // Check if the ProductCode, Name, and DeliveryLocation fields are valid
            if (ModelState.IsValidField("ProductCode") && ModelState.IsValidField("Name") && ModelState.IsValidField("DeliveryLocation"))
            {
                // If all fields are valid, redirect to the SearchProduct action
                TempData["SuccessMessage"] = "Product Fetched successfully!";
                return RedirectToAction("SearchProduct", productObj);
            }
            return View(productObj);
        }



        //[HttpGet]
        public ActionResult SearchProduct(Product productObj)
        {
            ViewBag.Title = "Product Available At";
            //Product product = new Product();
            //InLedger inledger = new InLedger();
            ViewBag.SuccessMessage = TempData["SuccessMessage"] as string;
            var productLocation = conn.Products.Join(conn.InLedgers, p => p.ProductCode, i => i.ProductCode, (p, i) => new { p, i })
                                    .Join(conn.InLedgerLocations, pi => pi.i.LedgerId, il => il.LedgerId, (pi, il) => new { pi, il })
                                    .Join(conn.Locations, pil => pil.il.LocationId, loc => loc.LocationId, (pil, loc) => new { pil, loc })
                                    .Where(m => m.pil.pi.p.ProductCode == productObj.ProductCode && m.pil.pi.p.Name == productObj.Name && m.loc.StatusCode == 1)
                                    .Select(m => new { Desc = m.loc.Description, locId = m.loc.LocationId }).ToList();

            foreach (var item in productLocation)
            {
                TempData.Keep();
                TempData.Add(item.locId.ToString(), item.Desc);
            }

            ViewData["Name"] = productObj.Name;
            ViewData["ProductCode"] = productObj.ProductCode;
            return View();
        }


        public ActionResult OutLedgerLocation(FormCollection frm)
        {
            ViewBag.Title = "Product Available At";
            string[] items_id = frm["locId"].Split(',');
            //foreach(var id in items_id)
            //{
            //    items_id.Add(Convert.ToInt32(id));
            //}
            //int locId = Convert.ToInt32(frm["locId"]);
            List<int> id_list = new List<int>();
            for (int i = 0; i < items_id.Length; i++)
            {
                id_list.Add(Convert.ToInt32(items_id[i]));
            }
            var locations = conn.Locations.Where(l => id_list.Contains(l.LocationId));

            foreach (var location in locations)
            {
                location.StatusCode = 0;
            }
            int productCode = Convert.ToInt32(frm["ProductCode"]);
            OutLedger outledgerData = new OutLedger();
            int n = Convert.ToInt32(conn.OutLedgers.Select(m => m.LedgerId).ToList().LastOrDefault());

            int last_outledgerLocid = Convert.ToInt32(conn.OutLedgerLocations.Select(m => m.OutLedgerLocationID).ToList().LastOrDefault());

            outledgerData.LedgerId = n + 1;
            outledgerData.OutDate = DateTime.Now;
            outledgerData.ProductCode = productCode;
            outledgerData.Quantity = 20 * id_list.Count;
            outledgerData.Validationvar = "valid";
            conn.OutLedgers.Add(outledgerData);

            foreach (var item in id_list)
            {
                OutLedgerLocation outledgerLocationdata = new OutLedgerLocation();
                //outledgerLocationdata.OutLedgerLocationID = last_outledgerLocid;
                outledgerLocationdata.ledgerId = n + 1;
                outledgerLocationdata.locationId = item;
                conn.OutLedgerLocations.Add(outledgerLocationdata);
            }
            conn.SaveChanges();

            return RedirectToAction("ProductCart", "ProductCart");
        }



    }
}