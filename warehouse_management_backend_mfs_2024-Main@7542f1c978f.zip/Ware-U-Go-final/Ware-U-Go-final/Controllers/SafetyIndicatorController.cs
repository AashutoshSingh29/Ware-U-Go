﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;

namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class SafetyIndicatorController : Controller
    {
        Ware_U_GoEntities obj = new Ware_U_GoEntities();
        // GET: SafetyIndicator
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public ActionResult Safety()
        {
            ViewBag.Title = "Safety Stock Indicator";
            var liist = obj.GetSafetyStockIndication().ToList();
            return View(liist);
        }
    }
}