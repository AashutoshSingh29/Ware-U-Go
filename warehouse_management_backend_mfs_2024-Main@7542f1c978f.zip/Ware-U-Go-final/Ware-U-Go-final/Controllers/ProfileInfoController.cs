﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;

namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class ProfileInfoController : Controller
    {
        Ware_U_GoEntities dbContext = new Ware_U_GoEntities();
        [HttpGet]
        public ActionResult Profile()
        {
            var email = Session["email"];

            if (email == null)
            {
                // Redirect to the login page
                return RedirectToAction("Login", "Account");
            }

            var query = from user in dbContext.UserTables
                        where user.Email == email
                        select new
                        {
                            user.Username,
                            user.Name,
                            user.UserType
                        };

            var result = query.FirstOrDefault();
            ViewBag.email = email;
            ViewBag.Username = query.FirstOrDefault().Username;
            ViewBag.Name = query.FirstOrDefault().Name;
            ViewBag.usertype = query.FirstOrDefault().UserType;
            return View();
        }



        public ActionResult Logout()
        {

            Session.Remove("email");

            return RedirectToAction("Login", "Account");

        }
        //[HttpPost]
        //public ActionResult Profile()
        //{
        //    return RedirectToAction("Login", "Account");
        //}
    }
}