﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;

namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class LocationController : Controller
    {
        Ware_U_GoEntities obj = new Ware_U_GoEntities();

        public ActionResult All_Location()
        {
            ViewBag.Title = "Available Locations";
            if (TempData["SuccessMessage"] != null)
            {
                ViewBag.SuccessMessage = TempData["SuccessMessage"];
            }
            //List<Location> allLoc = obj.Locations.ToList();
            List<Location> allLoc = obj.Locations.Where(loc => loc.StatusCode == 0).ToList();
            return View(allLoc);

        }
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult All_Location(InLedger inledger)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return RedirectToAction("Relocate", inledger);
        //    }
        //    List<Location> allLoc = obj.Locations.ToList();
        //    List<Location> allLoc = obj.Locations.Where(loc => loc.StatusCode == 0).ToList();
        //    return View(allLoc);
        //}

        [HttpPost]
        public ActionResult AssignLocations(FormCollection frm)
        {
            ViewBag.Title = "Available locations";

            TempData["SuccessMessage"] = "Location Assigned Successfully!";

            //var data = obj.Locations.Where(x => x.LocationId == model.LocationId).FirstOrDefault();
            //if (data != null)
            //{
            //    data.StatusCode = model.StatusCode;
            //    obj.SaveChanges();

            //}
            //return RedirectToAction("Index");
            List<int> selectedLocations = new List<int>();
            string[] loc_id = frm["selectedLocations"].Split(',');
            foreach (var id in loc_id)
            {
                selectedLocations.Add(Convert.ToInt32(id));
            }

            if (selectedLocations != null && selectedLocations.Any())
            {
                // Update status code for selected locations
                foreach (var locationId in selectedLocations)
                {
                    var location = obj.Locations.FirstOrDefault(x => x.LocationId == locationId);
                    if (location != null)
                    {
                        location.StatusCode = 1;
                    }
                }


            }


            foreach (var item in selectedLocations)
            {
                InLedgerLocation inLoc = new InLedgerLocation();
                inLoc.LedgerId = Convert.ToInt32(obj.InLedgers.Select(l => l.LedgerId).ToList().LastOrDefault()); ;
                inLoc.LocationId = item;
                obj.InLedgerLocations.Add(inLoc);
            }
            obj.SaveChanges();
            // Redirect to the same view or any other view as needed
            return RedirectToAction("All_Location");
        }
        [HttpPost]
        public ActionResult All_ReLocation(InLedger inledger)
        {
            ViewBag.Title = "Available Storage Relocation";
            Session["product_code"] = inledger.Product.ProductCode;

            List<Location> allLoc = obj.Locations.Where(loc => loc.StatusCode == 0).ToList();
            return View(allLoc);


        }
        [HttpPost]
        public ActionResult AssignReLocations(FormCollection frm)
        {
            ViewBag.Title = "Available Storage Relocation";

            int product_code = Convert.ToInt32(Session["product_code"]);
            var oldLocation = obj.Products.Join(obj.InLedgers, p => p.ProductCode, i => i.ProductCode, (p, i) => new { p, i })
                                    .Join(obj.InLedgerLocations, pi => pi.i.LedgerId, il => il.LedgerId, (pi, il) => new { pi, il })
                                    .Where(m => m.pi.p.ProductCode == product_code)
                                    .Select(m => m.il.LocationId).ToList().FirstOrDefault();

            List<int> selectedLocations = new List<int>();
            string[] loc_id = frm["selectedLocations"].Split(',');
            foreach (var id in loc_id)
            {
                selectedLocations.Add(Convert.ToInt32(id));
            }

            if (selectedLocations != null && selectedLocations.Any())
            {
                // Update status code for selected locations
                foreach (var locationId in selectedLocations)
                {
                    var location = obj.Locations.FirstOrDefault(x => x.LocationId == locationId);
                    if (location != null)
                    {
                        location.StatusCode = 1;

                    }
                }
                var old_location_reset = obj.Locations.FirstOrDefault(x => x.LocationId == oldLocation);
                if (old_location_reset != null)
                {
                    old_location_reset.StatusCode = 0;
                }


            }

            var inledgerLocations = obj.InLedgerLocations.Where(x => selectedLocations.Contains((int)x.LocationId));

            foreach (var inledgerLocation in inledgerLocations)
            {
                obj.InLedgerLocations.Remove(inledgerLocation);

            }

            foreach (var item in selectedLocations)
            {
                InLedgerLocation inLoc = new InLedgerLocation();
                inLoc.LedgerId = Convert.ToInt32(obj.InLedgers.Select(l => l.LedgerId).ToList().LastOrDefault()); ;
                inLoc.LocationId = item;
                obj.InLedgerLocations.Add(inLoc);
            }
            //Adding into relocation Table
            Relocation relocationObj = new Relocation();
            ////int n = Convert.ToInt32(obj.OutLedgers.Select(m => m.LedgerId).ToList().LastOrDefault());

            //int last_outledgerLocid = Convert.ToInt32(obj.OutLedgerLocations.Select(m => m.OutLedgerLocationID).ToList().LastOrDefault());
            relocationObj.productcode = Convert.ToInt32(Session["product_code"]);
            relocationObj.OldLocation = oldLocation;
            relocationObj.NewLocation = selectedLocations[0];
            relocationObj.Validationvar = "valid";
            obj.Relocations.Add(relocationObj);


            obj.SaveChanges();
            // Redirect to the same view or any other view as needed
            return View("RelSuccess");
        }
        public ActionResult RelSuccess()
        {
            return View();
        }

        // Relocation Function

        [HttpGet]
        public ActionResult Relocate()
        {
            ViewBag.Title = "Product Relocation";


            return View();
        }



        // Manual Location Relocation Functionality

        [HttpPost]
        public ActionResult ManualButton(InLedger inledger)
        {
            int product_code = inledger.Product.ProductCode;
            Session["product_code_manual"] = product_code;
            return View("ManualEntry");
        }
        public ActionResult ManualEntry()
        {
            return View();
        }

        [HttpPost]
        public ActionResult ManualEntry(FormCollection frm)
        {
            int product_code = Convert.ToInt32(Session["product_code_manual"]);
            var oldLocation = obj.Products.Join(obj.InLedgers, p => p.ProductCode, i => i.ProductCode, (p, i) => new { p, i })
                                    .Join(obj.InLedgerLocations, pi => pi.i.LedgerId, il => il.LedgerId, (pi, il) => new { pi, il })
                                    .Where(m => m.pi.p.ProductCode == product_code)
                                    .Select(m => m.il.LocationId).ToList().FirstOrDefault();
            int n = Convert.ToInt32(obj.Locations.Select(m => m.LocationId).ToList().LastOrDefault());
            Location l1 = new Location();
            l1.LocationId = n + 1;
            l1.Description = (frm["Rack"] + frm["Shelf"]).ToString();
            l1.StatusCode = 1;
            l1.Width = 50;
            l1.Length = 50;
            l1.Height = 50;
            obj.Locations.Add(l1);

            var old_location_reset = obj.Locations.FirstOrDefault(x => x.LocationId == oldLocation);
            if (old_location_reset != null)
            {
                old_location_reset.StatusCode = 0;
            }
            obj.SaveChanges();

            Ware_U_GoEntities obj2 = new Ware_U_GoEntities();

            int last_Locid = Convert.ToInt32(obj2.Locations.Select(m => m.LocationId).ToList().LastOrDefault());
            Relocation reloc = new Relocation();
            reloc.productcode = product_code;
            reloc.OldLocation = oldLocation;
            reloc.NewLocation = last_Locid;
            reloc.Validationvar = "valid";
            obj2.Relocations.Add(reloc);

            var recordToUpdate = obj2.InLedgerLocations.FirstOrDefault(x => x.LocationId == oldLocation);
            if (recordToUpdate != null)
            {
                recordToUpdate.LocationId = last_Locid;
            }
            obj2.SaveChanges();


            ViewBag.SuccessMessage = "Product Relocated Successfully";

            return View();
        }




    }
}