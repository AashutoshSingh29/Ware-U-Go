﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ware_U_Go.Filters;
using Ware_U_Go_final.Models;

namespace Ware_U_Go.Controllers
{
    [CustomAuthorize]
    public class InLedgersController : Controller
    {
        // GET: InLedgers
        InventoryBusinessLayer BO = new InventoryBusinessLayer();
        private Ware_U_GoEntities db = new Ware_U_GoEntities();
        private object context;

        // GET: InLedgers
        public ActionResult Index()
        {
            ViewBag.Title = "Product Inledger Form";
            //var inLedgers = db.InLedgers.Include(i => i.Product).Include(i => i.UserTable);
            //return View(inLedgers.ToList());
            return View();
        }


        public ActionResult Create()
        {
            ViewBag.Title = "Product Inledger Form";
            ViewBag.ProductCode = new SelectList(db.Products, "ProductCode", "ProductCode");
            return View();
        }

        // POST: InLedgers/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "LedgerId,InDate,Username,ProductCode,BatchNumber,Quantity,SupplierName,SupplierLocation,PONumber,PODate")] InLedger inLedger, [Bind(Include = "ProductCode,Name,CurrentStock,ThresholdStock,Length,Width,Height,Weight")] Product product)
        {

            ViewBag.Title = "Product Inledger Form";
            using (var context = new Ware_U_GoEntities())
            {
                if (ModelState.IsValid)
                {




                    var email = Session["email"];
                    var isValid = context.UserTables.FirstOrDefault(x => x.Email == email);


                    inLedger.ProductCode = product.ProductCode;
                    inLedger.Username = isValid.Username;
                    product.ThresholdStock = 50;
                    product.CurrentStock = inLedger.Quantity;

                    //db.Products.Add(product);
                    string result = BO.InboundAddorUpdate(product, product.CurrentStock);


                    db.InLedgers.Add(inLedger);

                    db.SaveChanges();
                    //Session["LedgerId"] = Convert.ToInt32(db.InLedgers.Select(l => l.LedgerId).ToList().LastOrDefault());
                    return RedirectToAction("All_location", "Location");
                }
            }
            //ViewBag.ProductCode = new SelectList(db.Products, "ProductCode", "Name", inLedger.ProductCode);
            return View(inLedger);
        }

    }
}