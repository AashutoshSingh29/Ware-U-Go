﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Ware_U_Go_final.Models;


namespace Ware_U_Go.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult Login()
        {
            ViewBag.Title = "Login to your account";
            return View();
        }

        [HttpPost]
        public ActionResult Login(UserTable model)
        {
            ViewBag.Title = "Login to your account";
            using (var context = new Ware_U_GoEntities())
            {
                bool isValid = context.UserTables.Any(x => x.Email == model.Email && x.Password == model.Password);
                if (isValid)
                {
                    FormsAuthentication.SetAuthCookie(model.Email, false);
                    Session["email"] = model.Email.ToString();

                    return RedirectToAction("Create", "InLedgers");
                }
                ModelState.AddModelError("", "Invalid id/password. Please try again");
                return View();
            }

        }


        public ActionResult Edit()
        {
            ViewBag.Title = "Set/Change Password";
            return View();
        }

        [HttpPost]
        public ActionResult Edit(UserTable model)
        {
            ViewBag.Title = "Set/Change Password";
            using (var context = new Ware_U_GoEntities())
            {
                var isValid = context.UserTables.FirstOrDefault(x => x.Email == model.Email);
                if (isValid != null && model.Password == model.ConfirmPassword)
                {
                    isValid.Password = model.Password;
                    context.SaveChanges();

                    return RedirectToAction("Login");
                }
              
                return View();
            }

        }
        public ActionResult SignUp()
        {
            ViewBag.Title = "Signup as new user";
            return View();
        }

        [HttpPost]
        public ActionResult SignUp(UserTable model)
        {
            ViewBag.Title = "Signup as new user";
            if (model.Email != null && model.Name != null && model.Username != null && model.UserType != null)
            {
                using (var context = new Ware_U_GoEntities())
                {
                    context.UserTables.Add(model);
                    context.SaveChanges();
                }
                return RedirectToAction("Login");
            }

            ModelState.AddModelError("", "Please enter value in all field");
            return View();
        }


        public ActionResult Logout()
        {
            // Clear the session
            Session["email"] = null;

            // Redirect to the login page
            TempData["AlertMessage"] = "You have been logged out.";
            return RedirectToAction("Login", "Account");
        }
    }
}