﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Ware_U_Go_final.Models;

namespace Ware_U_Go_final.Models
{
    public class InventoryBusinessLayer
    {
        public List<Product> damaged_products_list = new List<Product>();
        public List<Product> returned_products_list = new List<Product>();
        private Ware_U_GoEntities db = new Ware_U_GoEntities();
        public string InboundAddorUpdate(Product pr, double? quantity)
        {
            if (db.Products.Find(pr.ProductCode) != null)
            {
                var product = db.Products.Single(b => b.ProductCode == pr.ProductCode);
                product.CurrentStock += quantity;
                db.SaveChanges();
                return "success";
            }
            else
            {
                db.Products.Add(pr);
                db.SaveChanges();
                return "success";
            }
        }
        /*        public string InboundUpdate(double quantity, int productcode)
                {

                        var product = db.Products.Single(b => b.ProductCode == productcode);
                        product.CurrentStock += quantity;
                        db.SaveChanges();
                        return "success";
                }*/
        public string Outbound(double quantity, int productcode)
        {

            var product = db.Products.Single(b => b.ProductCode == productcode);
            if ((product.CurrentStock - quantity) <= 0)
            {
                return "Insufficient quantity";
            }
            product.CurrentStock -= quantity;
            db.SaveChanges();
            return "success";
        }

        /*        public string InboundAdd(Product pr)
                {
                    var product = pr;
                    db.Products.Add(product);
                    db.SaveChanges();
                    return "success";
                }*/
        public IEnumerable<Product> ProductList()
        {
            return db.Products.ToList();
        }
    }
}